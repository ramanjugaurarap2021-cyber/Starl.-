# Starl — native Android port starter

This is the first native Compose foundation for the supplied `Starl4.html` design. It is not a WebView wrapper.

## Open
1. Open this folder in Android Studio (recent version with AGP 8.10 support).
2. Let Gradle sync.
3. Run on Android 8.0+.
4. Grant audio permission when prompted. Starl queries MediaStore and plays local files with Media3 ExoPlayer.

## Current foundation
- Native Compose Home / Explore / Library / Search / Settings navigation.
- Floating translucent capsule navigation and initial glass styling.
- MediaStore local audio scan with content URIs.
- ExoPlayer queue playback and a full-screen player surface.

## Remaining port work
The HTML source has substantially more behavior than a UI shell: custom animated nav-pill physics and drag gestures, mini-player collapse/expand, queue editing and autoplay, synced lyrics, audio effects / equalizer, output routing, account/onboarding persistence, full settings model, replay statistics, context/hold menus, and detailed Liquid Glass rendering. These need to be ported as native modules rather than pretending the starter already implements them.

Package: `com.starl.music`
