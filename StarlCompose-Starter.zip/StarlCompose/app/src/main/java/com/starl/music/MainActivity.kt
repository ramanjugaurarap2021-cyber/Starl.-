package com.starl.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.starl.music.data.AudioRepository
import com.starl.music.data.AudioTrack
import com.starl.music.player.PlaybackController

private val Bg = Color(0xFF08080A)
private val SurfaceGlass = Color(0xCC242428)
private val Muted = Color(0xFF92929A)
private val Accent = Color(0xFFFF3155)

class MainActivity : ComponentActivity() {
    private lateinit var playback: PlaybackController
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        playback = PlaybackController(this)
        setContent { StarlApp(playback) }
    }
    override fun onDestroy() {
        playback.release()
        super.onDestroy()
    }
}

@Composable
private fun StarlApp(playback: PlaybackController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tracks by remember { mutableStateOf(emptyList<AudioTrack>()) }
    var selected by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var hasPermission by remember { mutableStateOf(false) }
    var playerExpanded by remember { mutableStateOf(false) }

    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        if (granted) tracks = AudioRepository(context).scan()
    }
    LaunchedEffect(Unit) {
        hasPermission = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) tracks = AudioRepository(context).scan()
    }
    DisposableEffect(playback.player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selected = playback.player.currentMediaItemIndex.coerceAtLeast(0)
            }
        }
        playback.player.addListener(listener)
        onDispose { playback.player.removeListener(listener) }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = SurfaceGlass, primary = Accent)) {
        Box(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Starl", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-.7).sp)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { tab = "Settings" }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
                }
                AnimatedContent(tab, label = "tab-content", modifier = Modifier.weight(1f)) { page ->
                    when (page) {
                        "Search" -> {
                            Column {
                                Text("Search", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(14.dp))
                                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Songs, albums, artists") }, singleLine = true)
                                Spacer(Modifier.height(12.dp))
                                TrackList(tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, onPlay = { t ->
                                    selected = tracks.indexOf(t).coerceAtLeast(0); playback.play(t)
                                })
                            }
                        }
                        "Library" -> Column {
                            Text("Library", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Text("${tracks.size} songs on this device", color = Muted)
                            Spacer(Modifier.height(16.dp))
                            TrackList(tracks, onPlay = { t -> selected = tracks.indexOf(t).coerceAtLeast(0); playback.play(t) })
                        }
                        "Explore" -> Column {
                            Text("Explore", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(18.dp))
                            Text("Browse by mood", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            listOf("Chill", "Workout", "Focus", "Late night", "Party", "Sad hours").chunked(2).forEach { pair ->
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                                    pair.forEach { mood -> Box(Modifier.weight(1f).height(82.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF553A62), Color(0xFF222D48)))).clickable { tab = "Library" }.padding(14.dp), contentAlignment = Alignment.BottomStart) { Text(mood, fontWeight = FontWeight.Bold) } }
                                }
                            }
                            Text("Recently added", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            TrackList(tracks.take(8), onPlay = { t -> selected = tracks.indexOf(t).coerceAtLeast(0); playback.play(t) })
                        }
                        "Settings" -> Column {
                            Text("Settings", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(18.dp))
                            SettingRow("Local music", "Scan audio stored on this device") { tracks = AudioRepository(context).scan() }
                            SettingRow("Appearance", "Dark theme · Liquid Glass styling") {}
                            SettingRow("Playback", "Playback engine: Media3 ExoPlayer") {}
                            SettingRow("About Starl", "Offline music player") {}
                        }
                        else -> Column {
                            Text("Listen now", fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Recents", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            if (!hasPermission) {
                                Spacer(Modifier.height(20.dp))
                                Text("Let Starl scan music stored on your device.", color = Muted)
                                Button(onClick = { launcher.launch(permission) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Allow music access") }
                            } else if (tracks.isEmpty()) {
                                Spacer(Modifier.height(24.dp)); Text("No music found on this device.", color = Muted)
                                Text("Add audio files to your Music folder, then refresh.", color = Muted, fontSize = 13.sp)
                                TextButton(onClick = { tracks = AudioRepository(context).scan() }) { Text("Scan again") }
                            } else TrackList(tracks.take(12), onPlay = { t -> selected = tracks.indexOf(t).coerceAtLeast(0); playback.playQueue(tracks, selected); playerExpanded = true })
                        }
                    }
                }
            }
            // Floating glass capsule navigation
            Row(Modifier.align(Alignment.BottomCenter).padding(start = 14.dp, end = 14.dp, bottom = 16.dp).fillMaxWidth().height(66.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.weight(1f).fillMaxHeight().clip(CircleShape).background(SurfaceGlass).border(1.dp, Color.White.copy(.12f), CircleShape).padding(5.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    listOf("Home", "Explore", "Library").forEach { item ->
                        val active = tab == item
                        val scale by animateFloatAsState(if (active) 1f else .94f, spring(), label = "nav-scale")
                        Column(Modifier.weight(1f).fillMaxHeight().scale(scale).clip(CircleShape).background(if (active) Color.White.copy(.13f) else Color.Transparent).clickable { tab = item }.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(when (item) { "Home" -> Icons.Default.Home; "Explore" -> Icons.Default.GridView; else -> Icons.Default.LibraryMusic }, null, tint = if (active) Color.White else Muted)
                            Text(item, fontSize = 10.sp, color = if (active) Color.White else Muted)
                        }
                    }
                }
                Box(Modifier.size(62.dp).clip(CircleShape).background(SurfaceGlass).border(1.dp, Color.White.copy(.12f), CircleShape).clickable { tab = "Search" }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
            }
            if (playerExpanded) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(.65f)).clickable { playerExpanded = false })
                Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF303044), Bg))).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { playerExpanded = false }) { Icon(Icons.Default.KeyboardArrowDown, "Close") }; Spacer(Modifier.weight(1f)); Text("NOW PLAYING", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); IconButton(onClick = {}) { Icon(Icons.Default.MoreHoriz, "More") } }
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Accent.copy(.6f), Color(0xFF292947)))))
                    Spacer(Modifier.height(28.dp))
                    Text(tracks.getOrNull(selected)?.title ?: "Nothing playing", fontSize = 25.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(tracks.getOrNull(selected)?.artist ?: "Choose a song", color = Muted)
                    Spacer(Modifier.height(30.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { playback.player.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, "Previous", modifier = Modifier.size(34.dp)) }
                        IconButton(onClick = { if (playback.player.isPlaying) playback.player.pause() else playback.player.play() }, modifier = Modifier.size(76.dp).background(Color.White, CircleShape)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play", tint = Bg, modifier = Modifier.size(42.dp)) }
                        IconButton(onClick = { playback.player.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Next", modifier = Modifier.size(34.dp)) }
                    }
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun TrackList(tracks: List<AudioTrack>, onPlay: (AudioTrack) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(bottom = 112.dp)) {
        itemsIndexed(tracks, key = { _, t -> t.id }) { _, track ->
            Row(Modifier.fillMaxWidth().clickable { onPlay(track) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(11.dp)).background(Brush.linearGradient(listOf(Color(0xFF59435D), Color(0xFF263D55)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(.85f)) }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { onPlay(track) }) { Icon(Icons.Default.PlayArrow, "Play", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(subtitle, color = Muted, fontSize = 13.sp) }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
    HorizontalDivider(color = Color.White.copy(.08f))
}
